﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoneyVision.Domain.Entities.User.Responses
{
     public class ULoginResp
     {
          public bool Status { get; set; }
          public string StatusMsg { get; set; }
     }
}
